FIRE BEERNET TOOL - CLASSIC

To jest klasyczna wersja z terminalowym wygladem PowerShell.
Nie zawiera instalatora ani wlasnego pliku EXE.
Nie wymaga Pythona - Windows ma PowerShell wbudowany.

URUCHOMIENIE
1. Rozpakuj caly ZIP do wybranego folderu.
2. Uruchom START_MONITOR.bat.

Nie usuwaj plikow .ps1 - sa czescia narzedzia.
Logi sa zapisywane automatycznie w folderze logs.

AKTUALIZACJE
Opcja [5] AKTUALIZACJA tylko sprawdza numer wersji na oficjalnej stronie.
Gdy pojawi sie nowsza wersja, mozesz nacisnac S, aby otworzyc strone pobierania.
Program nigdy nie pobiera ani nie uruchamia aktualizacji automatycznie.
