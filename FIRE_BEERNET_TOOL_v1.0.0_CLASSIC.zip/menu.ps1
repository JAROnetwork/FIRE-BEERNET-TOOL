# Main menu. It is intentionally ASCII-only apart from the title built at runtime,
# so Windows PowerShell 5.1 cannot misread the file encoding.
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false)
$Title = 'DDoS ALERT MONITOR'
$Subtitle = 'WiFi NARZEDZIE DIAGNOSTYCZNE'
$NetworkTitle = 'INFORMACJE SIECIOWE'
$SpeedTitle = 'TEST PREDKOSCI'
$AppVersion = '1.0.0'
$FireTitle = 'FIRE BEERNET TOOL v1.0.0'
$Signature = 'by JAROnetwork ' + [char]0x00A9
$LogoBase64 = '4qCm4qOE4qCA4qCA4qC54qOE4qOg4qCe4qCA4qGA4qCR4qCm4qCW4qCS4qCS4qKm4qGACuKggOKggOKggOKguOKhhOKggOKggOKggOKggOKggOKggOKgv+KjtuKjtuKjv+Kjv+Kjt+KjpOKiuQrioIDioIDioIDioIDioIjioJPioJrioIviooniobfioIDioIDio6DioKTio53io7/io7/iob/iobgK4qCA4qCA4qCA4qCA4qCA4qCA4qCA4qCA4qCZ4qCy4qC24qCe4qCB4qKw4qO94qO/4qG/4qGa4qCBCuKggOKggOKggOKggOKggOKggOKggOKggOKggOKggOKggOKigOKjsOKii+Kjv+Khv+Kgn+KggQrioIDioIDioIDioIDioIDioIDioIDioIDio6DioLTioJrio4nio6Hio7/iob/ioIEK4qCA4qCA4qCA4qCA4qCA4qCA4qKA4qG04qCB4qO04qO/4qO/4qO/4qO/4qGHCuKggOKggOKggOKggOKggOKioOKgnuKigOKjvuKjv+Kjv+Kjv+Kjv+Kih+KhhwrioIDioIDioIDioIDio7DioIvio7Dio7/io7/io7/io7/io7/io6vioI8K4qCA4qCA4qKA4qG+4qKB4qO84qO/4qO/4qO/4qO/4qG/4qG14qCDCuKggOKggOKhnuKioOKjvuKjv+Kjv+Kjv+Kjv+Kiv+KhnuKggQrioIDioIDioLnio77io7/io7/io7/iob/io7vioI8K4qCA4qCA4qCA4qCA4qCZ4qC74qC/4qCf'
$Logo = [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($LogoBase64))

function Write-Banner {
    param([switch]$WifiOnly, [switch]$NetworkOnly, [switch]$SpeedOnly)
    $left = @($Logo -split "`n")
    # The text block is vertically centred against the bottle.
    $right = if ($SpeedOnly) {
        @("", "", "", "  $FireTitle", "", "  $SpeedTitle", "", "", "", "  $Signature", "", "", "")
    } elseif ($NetworkOnly) {
        @("", "", "", "  $FireTitle", "", "  $NetworkTitle", "", "", "", "  $Signature", "", "", "")
    } elseif ($WifiOnly) {
        @("", "", "", "  $FireTitle", "", "  $Subtitle", "", "", "", "  $Signature", "", "", "")
    } else {
        @("", "", "", "  $FireTitle", "", "  $Title", "  $Subtitle", "  $NetworkTitle", "  $SpeedTitle", "", "  $Signature", "", "")
    }
    $height = [Math]::Max($left.Count, $right.Count)
    for ($i = 0; $i -lt $height; $i++) {
        $leftText = if ($i -lt $left.Count) { $left[$i] } else { '' }
        $rightText = if ($i -lt $right.Count) { $right[$i] } else { '' }
        Write-Host ($leftText.PadRight(28)) -NoNewline -ForegroundColor Red
        Write-Host ' | ' -NoNewline -ForegroundColor Red
        $headerColor = if ($rightText -match 'DDoS') { 'Red' } elseif ($rightText -match 'WiFi') { 'Cyan' } elseif ($rightText -match 'INFORMACJE') { 'Yellow' } elseif ($rightText -match 'PREDKOSCI') { 'Blue' } elseif (($rightText -match 'FIRE') -or ($rightText -match 'JAROnetwork')) { 'White' } else { 'DarkCyan' }
        Write-Host $rightText -ForegroundColor $headerColor
    }
}

function Show-WiresharkStatus {
    Clear-Host
    Write-Banner
    Write-Host '  Integracja z Wireshark / tshark' -ForegroundColor Cyan
    Write-Host ('-' * 68) -ForegroundColor DarkCyan
    $wireshark = Get-Command wireshark.exe -ErrorAction SilentlyContinue
    $tshark = Get-Command tshark.exe -ErrorAction SilentlyContinue
    if ($wireshark -or $tshark) {
        Write-Host 'Wireshark lub tshark zostal wykryty.' -ForegroundColor Green
        if ($wireshark) { Write-Host "Wireshark: $($wireshark.Source)" -ForegroundColor Cyan }
        if ($tshark) { Write-Host "tshark:    $($tshark.Source)" -ForegroundColor Cyan }
        Write-Host ''
        Write-Host 'Modul jest gotowy do przyszlego zbierania dowodow incydentu.' -ForegroundColor Cyan
    } else {
        Write-Host 'Nie znaleziono Wireshark ani tshark w systemowej sciezce.' -ForegroundColor Yellow
        Write-Host ''
        Write-Host 'Monitor nadal dziala normalnie. Integracja z przechwytywaniem' -ForegroundColor Cyan
        Write-Host 'pakietow moze zostac dodana po zainstalowaniu Wireshark.' -ForegroundColor Cyan
    }
    Write-Host ''
    Write-Host 'Ta opcja tylko sprawdza dostepnosc programu.' -ForegroundColor DarkCyan
    Write-Host 'Nie uruchamia przechwytywania ani nie zapisuje pakietow.' -ForegroundColor DarkCyan
    Read-Host 'Nacisnij Enter, aby wrocic do menu' | Out-Null
}

while ($true) {
    Clear-Host
    Write-Banner
    Write-Host ''
    Write-Host '[1] DDoS ALERT MONITOR' -ForegroundColor Red
    Write-Host ''
    Write-Host '[2] WiFi NARZEDZIE DIAGNOSTYCZNE' -ForegroundColor Cyan
    Write-Host ''
    Write-Host '[3] INFORMACJE SIECIOWE' -ForegroundColor Yellow
    Write-Host ''
    Write-Host '[4] TEST PREDKOSCI' -ForegroundColor Blue
    Write-Host ''
    Write-Host '[5] AKTUALIZACJA' -ForegroundColor Green
    Write-Host ''
    Write-Host '[0] WYJSCIE' -ForegroundColor Red
    Write-Host ''
    $choice = Read-Host 'Wybierz [0-5] i zatwierdz ENTER'
    switch ($choice.Trim()) {
        '1' { & (Join-Path $PSScriptRoot 'monitor.ps1') }
        '2' { & (Join-Path $PSScriptRoot 'wifi_diagnostic.ps1') }
        '3' { & (Join-Path $PSScriptRoot 'network_info.ps1') }
        '4' { & (Join-Path $PSScriptRoot 'speed_test.ps1') }
        '5' { & (Join-Path $PSScriptRoot 'updater.ps1') -CurrentVersion $AppVersion }
        '0' { exit 0 }
        default { Write-Host 'Wybierz opcje od 0 do 5.' -ForegroundColor Yellow; Start-Sleep -Seconds 1 }
    }
}
