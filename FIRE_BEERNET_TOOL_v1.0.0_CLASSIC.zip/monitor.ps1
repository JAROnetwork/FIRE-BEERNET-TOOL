<#
 Local, defensive reachability monitor. Uses standard Windows ping probes only.
 Alerts describe connectivity symptoms; they do not prove a DoS/DDoS attack.
#>
param(
    # Empty value means: automatically use Windows' active default gateway.
    [string]$Router = '',
    [string[]]$Endpoints = @('1.1.1.1', '8.8.8.8', '9.9.9.9'),
    [double]$IntervalSeconds = 1,
    [int]$TimeoutMs = 900,
    [int]$OutageSeconds = 5,
    [double]$AnomalyFactor = 3
)

$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false)

function Get-ActiveDefaultGateway {
    # Prefer the lowest-metric IPv4 default route used by Windows.
    try {
        $route = Get-NetRoute -AddressFamily IPv4 -DestinationPrefix '0.0.0.0/0' -ErrorAction Stop |
            Where-Object { $_.NextHop -and $_.NextHop -ne '0.0.0.0' } |
            Sort-Object @{ Expression = 'RouteMetric'; Ascending = $true }, @{ Expression = 'InterfaceMetric'; Ascending = $true } |
            Select-Object -First 1
        if ($route -and $route.NextHop) { return [string]$route.NextHop }
    } catch { }

    # Compatibility fallback for older Windows / PowerShell installations.
    try {
        $route = Get-CimInstance Win32_IP4RouteTable -ErrorAction Stop |
            Where-Object { $_.Destination -eq '0.0.0.0' -and $_.Mask -eq '0.0.0.0' -and $_.NextHop -ne '0.0.0.0' } |
            Sort-Object Metric1 | Select-Object -First 1
        if ($route -and $route.NextHop) { return [string]$route.NextHop }
    } catch { }
    return $null
}

$routerSource = 'podany recznie'
if ([string]::IsNullOrWhiteSpace($Router)) {
    $Router = Get-ActiveDefaultGateway
    if ($Router) {
        $routerSource = 'wykryty automatycznie z aktywnej bramy Windows'
    } else {
        $Router = '192.168.0.1'
        $routerSource = 'zapasowy adres (nie udalo sie wykryc bramy Windows)'
    }
}
$Title = 'DDoS ALERT MONITOR'
$Subtitle = 'WiFi NARZEDZIE DIAGNOSTYCZNE'
$FireTitle = 'FIRE BEERNET TOOL'
$Signature = 'by JAROnetwork ' + [char]0x00A9
$LogoBase64 = '4qCm4qOE4qCA4qCA4qC54qOE4qOg4qCe4qCA4qGA4qCR4qCm4qCW4qCS4qCS4qKm4qGACuKggOKggOKggOKguOKhhOKggOKggOKggOKggOKggOKggOKgv+KjtuKjtuKjv+Kjv+Kjt+KjpOKiuQrioIDioIDioIDioIDioIjioJPioJrioIviooniobfioIDioIDio6DioKTio53io7/io7/iob/iobgK4qCA4qCA4qCA4qCA4qCA4qCA4qCA4qCA4qCZ4qCy4qC24qCe4qCB4qKw4qO94qO/4qG/4qGa4qCBCuKggOKggOKggOKggOKggOKggOKggOKggOKggOKggOKggOKigOKjsOKii+Kjv+Khv+Kgn+KggQrioIDioIDioIDioIDioIDioIDioIDioIDio6DioLTioJrio4nio6Hio7/iob/ioIEK4qCA4qCA4qCA4qCA4qCA4qCA4qKA4qG04qCB4qO04qO/4qO/4qO/4qO/4qGHCuKggOKggOKggOKggOKggOKioOKgnuKigOKjvuKjv+Kjv+Kjv+Kjv+Kih+KhhwrioIDioIDioIDioIDio7DioIvio7Dio7/io7/io7/io7/io7/io6vioI8K4qCA4qCA4qKA4qG+4qKB4qO84qO/4qO/4qO/4qO/4qG/4qG14qCDCuKggOKggOKhnuKioOKjvuKjv+Kjv+Kjv+Kjv+Kiv+KhnuKggQrioIDioIDioLnio77io7/io7/io7/iob/io7vioI8K4qCA4qCA4qCA4qCA4qCZ4qC74qC/4qCf'
$Logo = [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($LogoBase64))

function Write-Banner {
    $left = @($Logo -split "`n")
    # The text block is vertically centred against the bottle.
    $right = @("", "", "", "  $FireTitle", "", "  $Title", "", "", "", "  $Signature", "", "", "")
    $height = [Math]::Max($left.Count, $right.Count)
    for ($i = 0; $i -lt $height; $i++) {
        $leftText = if ($i -lt $left.Count) { $left[$i] } else { '' }
        $rightText = if ($i -lt $right.Count) { $right[$i] } else { '' }
        Write-Host ($leftText.PadRight(28)) -NoNewline -ForegroundColor Red
        Write-Host ' | ' -NoNewline -ForegroundColor Red
        $headerColor = if ($rightText -match 'DDoS') { 'Red' } elseif (($rightText -match 'FIRE') -or ($rightText -match 'JAROnetwork')) { 'White' } else { 'DarkCyan' }
        Write-Host $rightText -ForegroundColor $headerColor
    }
}
$LogDir = Join-Path $PSScriptRoot 'logs'
New-Item -ItemType Directory -Force -Path $LogDir | Out-Null
$stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
$CsvPath = Join-Path $LogDir "network_$stamp.csv"
$JsonlPath = Join-Path $LogDir "network_$stamp.jsonl"
$history = New-Object System.Collections.Generic.List[double]
$outageStart = $null

function Invoke-HealthPing([string]$Target, [int]$WaitMs) {
    try {
        $raw = & "$env:SystemRoot\System32\ping.exe" -n 1 -w $WaitMs $Target 2>&1 | Out-String
        $success = ($LASTEXITCODE -eq 0)
        $match = [regex]::Match($raw, '(?i)(?:time|czas)\s*[=<]\s*(\d+(?:[\.,]\d+)?)\s*ms')
        $rtt = $null
        if ($match.Success) { $rtt = [double]($match.Groups[1].Value.Replace(',', '.')) }
        $detail = if ($success) { 'reply' } else { (($raw -split "`r?`n" | Where-Object { $_.Trim() } | Select-Object -Last 1).Trim()) }
        if (-not $detail) { $detail = 'no reply' }
        return [pscustomobject]@{ target = $Target; ok = $success; rtt_ms = $rtt; detail = $detail.Substring(0, [Math]::Min(180, $detail.Length)) }
    } catch {
        return [pscustomobject]@{ target = $Target; ok = $false; rtt_ms = $null; detail = $_.Exception.Message }
    }
}

function Get-Status($routerResult, $publicResults) {
    $ok = @($publicResults | Where-Object ok)
    $rtts = @($ok | Where-Object { $null -ne $_.rtt_ms } | ForEach-Object { [double]$_.rtt_ms })
    $avg = if ($rtts.Count) { [Math]::Round((($rtts | Measure-Object -Average).Average), 1) } else { $null }
    $loss = [Math]::Round(100 * ($publicResults.Count - $ok.Count) / $publicResults.Count, 1)
    $now = [DateTimeOffset]::UtcNow
    if ($routerResult.ok -and $ok.Count -eq 0) {
        if ($null -eq $script:outageStart) { $script:outageStart = $now }
        $seconds = ($now - $script:outageStart).TotalSeconds
        if ($seconds -ge $OutageSeconds) {
            return @('POTENCJALNY INCYDENT', "Internet niedostepny przez $([Math]::Floor($seconds))s, router nadal odpowiada. To objaw problemu z laczem/trasa; nie potwierdza DDoS.", $avg, $loss)
        }
        return @('OSTRZEZENIE', "Brak odpowiedzi z publicznych endpointow ($([Math]::Floor($seconds))s).", $avg, $loss)
    }
    $script:outageStart = $null
    if (-not $routerResult.ok) { return @('OSTRZEZENIE', 'Router nie odpowiada — mozliwy problem lokalnej sieci, Wi-Fi lub zasilania.', $avg, $loss) }
    if ($loss -ge 50) { return @('OSTRZEZENIE', "Wysoka utrata odpowiedzi publicznych: $loss%.", $avg, $loss) }
    if (($null -ne $avg) -and $history.Count -ge 8) {
        $baseline = ($history | Measure-Object -Average).Average
        if ($baseline -gt 0 -and $avg -ge [Math]::Max(80, $baseline * $AnomalyFactor)) {
            return @('ANOMALIA', "Nagly wzrost RTT: $avg ms (typowo $([Math]::Round($baseline, 0)) ms).", $avg, $loss)
        }
    }
    return @('OK', 'Lacze odpowiada w granicach biezacych pomiarow.', $avg, $loss)
}

Clear-Host
Write-Banner
Write-Host ''
Write-Host 'UWAGA: alarm opisuje objaw polaczenia, nie potwierdza ataku DDoS.' -ForegroundColor White
Write-Host 'Ctrl+C zatrzymuje monitor.' -ForegroundColor White
Write-Host ''
Write-Host 'STATUS: PAUZA - nacisnij S, aby rozpoczac monitorowanie.' -ForegroundColor Yellow
Write-Host ''
Write-Host "ROUTER LAN:             $Router ($routerSource)" -ForegroundColor White
Write-Host "PUBLICZNE ENDPOINTY:    $($Endpoints -join ', ')" -ForegroundColor White
Write-Host "INTERWAL POMIARU:       $IntervalSeconds s" -ForegroundColor White
Write-Host "ALARM PO UTRACIE:       $OutageSeconds s" -ForegroundColor White
Write-Host "LOG CSV:                $CsvPath" -ForegroundColor White
Write-Host "LOG JSON:               $JsonlPath" -ForegroundColor White
Write-Host ''
Write-Host 'LIVE LOG:' -ForegroundColor White
Write-Host '[S] START' -ForegroundColor Green
Write-Host '[P] PAUZA' -ForegroundColor Yellow
Write-Host '[0] WYJSCIE' -ForegroundColor Red
Write-Host ''

$monitoring = $false
$running = $true
while ($running) {
    if ([Console]::KeyAvailable) {
        $key = [Console]::ReadKey($true).Key.ToString()
        switch ($key) {
            'S' { if (-not $monitoring) { $monitoring = $true; Write-Host 'STATUS: MONITORING W TOKU' -ForegroundColor Green } }
            'P' { if ($monitoring) { $monitoring = $false; Write-Host 'STATUS: PAUZA' -ForegroundColor Yellow } }
            'D0' { $running = $false }
            'NumPad0' { $running = $false }
        }
    }
    if (-not $running) { break }
    if (-not $monitoring) {
        Start-Sleep -Milliseconds 80
        continue
    }
    $started = Get-Date
    $routerResult = Invoke-HealthPing $Router $TimeoutMs
    $publicResults = @($Endpoints | ForEach-Object { Invoke-HealthPing $_ $TimeoutMs })
    $status, $reason, $avgRtt, $loss = Get-Status $routerResult $publicResults
    if ($null -ne $avgRtt) { $history.Add([double]$avgRtt); if ($history.Count -gt 30) { $history.RemoveAt(0) } }
    $timestamp = (Get-Date).ToString('o')
    $targets = @{}
    foreach ($item in @($routerResult) + $publicResults) { $targets[$item.target] = $item }
    $event = [ordered]@{ timestamp=$timestamp; router_ok=[bool]$routerResult.ok; router_rtt_ms=$routerResult.rtt_ms; public_ok_count=$publicResults.Where({$_.ok}).Count; public_total=$publicResults.Count; public_loss_pct=$loss; public_rtt_avg_ms=$avgRtt; status=$status; reason=$reason; targets=$targets }
    [pscustomobject]@{ timestamp=$event.timestamp; router_ok=$event.router_ok; router_rtt_ms=$event.router_rtt_ms; public_ok_count=$event.public_ok_count; public_total=$event.public_total; public_loss_pct=$event.public_loss_pct; public_rtt_avg_ms=$event.public_rtt_avg_ms; status=$event.status; reason=$event.reason; targets=($targets | ConvertTo-Json -Compress -Depth 4) } | Export-Csv -Path $CsvPath -NoTypeInformation -Append -Encoding utf8
    ($event | ConvertTo-Json -Compress -Depth 5) | Add-Content -Path $JsonlPath -Encoding utf8
    $routerText = if ($null -ne $routerResult.rtt_ms) { "$($routerResult.rtt_ms) ms" } else { 'brak' }
    $avgText = if ($null -ne $avgRtt) { "$avgRtt ms" } else { 'brak' }
    $routerColor = if ($routerResult.ok) { 'White' } else { 'Red' }
    $publicColor = if ($event.public_ok_count -eq $event.public_total) { 'White' } else { 'Red' }
    $rttColor = if ($null -eq $avgRtt) { 'Red' } else { 'White' }
    $lossColor = if ($loss -gt 0) { 'Red' } else { 'White' }
    $statusColor = if ($status -eq 'OK') { 'White' } else { 'Red' }
    Write-Host "$timestamp  Router: " -NoNewline -ForegroundColor White
    Write-Host "$(if ($routerResult.ok) {'OK'} else {'BRAK'})" -NoNewline -ForegroundColor $routerColor
    Write-Host " ($routerText)  Publiczne: " -NoNewline -ForegroundColor White
    Write-Host "$($event.public_ok_count)/$($event.public_total)" -NoNewline -ForegroundColor $publicColor
    Write-Host '  RTT: ' -NoNewline -ForegroundColor White
    Write-Host $avgText -NoNewline -ForegroundColor $rttColor
    Write-Host '  Loss: ' -NoNewline -ForegroundColor White
    Write-Host "$loss%" -NoNewline -ForegroundColor $lossColor
    Write-Host "  [$status]" -ForegroundColor $statusColor
    if ($status -ne 'OK') { Write-Host "  -> $reason" -ForegroundColor Red }
    $wait = $IntervalSeconds - ((Get-Date) - $started).TotalSeconds
    while (($wait -gt 0) -and $running -and $monitoring) {
        if ([Console]::KeyAvailable) {
            $key = [Console]::ReadKey($true).Key.ToString()
            switch ($key) {
                'P' { $monitoring = $false; Write-Host 'STATUS: PAUZA' -ForegroundColor Yellow }
                'D0' { $running = $false }
                'NumPad0' { $running = $false }
            }
        }
        Start-Sleep -Milliseconds ([int][Math]::Min(80, $wait * 1000))
        $wait = $IntervalSeconds - ((Get-Date) - $started).TotalSeconds
    }
}
