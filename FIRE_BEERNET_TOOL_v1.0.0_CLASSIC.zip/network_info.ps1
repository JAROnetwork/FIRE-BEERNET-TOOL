# Read-only display of the local Windows network configuration.
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false)
$OutputEncoding = [Console]::OutputEncoding
& chcp 65001 | Out-Null

Clear-Host
if (Get-Command Write-Banner -ErrorAction SilentlyContinue) {
    Write-Banner -NetworkOnly
} else {
    Write-Host 'INFORMACJE SIECIOWE' -ForegroundColor Yellow
}
Write-Host ''

& ipconfig /all | ForEach-Object {
    $line = [string]$_
    # Adapter names stand out in bright yellow; details remain white.
    if (($line -match '(?i)^Windows IP Configuration') -or ($line -match '(?i)(adapter|karta).*:$')) {
        Write-Host ''
        Write-Host $line.Trim() -ForegroundColor Yellow
    } elseif ($line.Trim()) {
        Write-Host $line.TrimEnd() -ForegroundColor White
    }
}

Write-Host ''
Write-Host '[0] WYJSCIE' -ForegroundColor Red
while ($true) {
    $key = [Console]::ReadKey($true).Key.ToString()
    if (($key -eq 'D0') -or ($key -eq 'NumPad0')) { return }
}
