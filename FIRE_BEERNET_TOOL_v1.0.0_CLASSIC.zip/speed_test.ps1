# Test predkosci uruchamiany wyłącznie po wybraniu [S].
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false)

function Find-OoklaSpeedtest {
    foreach ($name in @('speedtest.exe', 'speedtest')) {
        $command = Get-Command $name -ErrorAction SilentlyContinue | Select-Object -First 1
        if ($command -and $command.Source) { return $command.Source }
    }
    $wingetRoot = Join-Path $env:LOCALAPPDATA 'Microsoft\WinGet\Packages'
    if (Test-Path $wingetRoot) {
        $candidate = Get-ChildItem -Path $wingetRoot -Filter 'speedtest.exe' -Recurse -ErrorAction SilentlyContinue |
            Where-Object { $_.FullName -match 'Ookla\.Speedtest\.CLI' } | Select-Object -First 1
        if ($candidate) { return $candidate.FullName }
    }
    $null
}

function Show-SpeedScreen($Result) {
    Clear-Host
    if (Get-Command Write-Banner -ErrorAction SilentlyContinue) { Write-Banner -SpeedOnly }
    else { Write-Host 'TEST PREDKOSCI' -ForegroundColor Blue }
    Write-Host ''
    Write-Host 'Test uruchamia sie tylko po S. Najpierw korzysta z Speedtest by Ookla.' -ForegroundColor White
    Write-Host 'Wynik bedzie porownywalny z komenda speedtest / aplikacja Ookla.' -ForegroundColor White
    Write-Host 'Gdy Ookla nie jest dostepna, wlacza dluzszy test zapasowy Cloudflare.' -ForegroundColor White
    Write-Host ''
    if ($Result) {
        Write-Host "SILNIK:               $($Result.Engine)" -ForegroundColor Blue
        if ($Result.Server) { Write-Host "SERWER:               $($Result.Server)" -ForegroundColor White }
        if ($Result.Isp) { Write-Host "ISP:                  $($Result.Isp)" -ForegroundColor White }
        Write-Host "PING:                 $($Result.PingMs) ms" -ForegroundColor Blue
        Write-Host "POBIERANIE:           $($Result.DownloadMbps) Mb/s" -ForegroundColor Blue
        Write-Host "WYSYLANIE:            $($Result.UploadMbps) Mb/s" -ForegroundColor Blue
        if ($null -ne $Result.PacketLoss) { Write-Host "UTRATA PAKIETOW:      $($Result.PacketLoss)%" -ForegroundColor White }
        if ($Result.DownloadedMB) { Write-Host "POBRANO:              $($Result.DownloadedMB) MB w $($Result.DownloadSeconds) s" -ForegroundColor White }
        if ($Result.UploadedMB) { Write-Host "WYSŁANO:              $($Result.UploadedMB) MB w $($Result.UploadSeconds) s" -ForegroundColor White }
        if ($Result.ResultUrl) { Write-Host "WYNIK OOKLA:          $($Result.ResultUrl)" -ForegroundColor White }
    } else {
        if (Find-OoklaSpeedtest) { Write-Host 'STATUS: GOTOWY - WYKRYTO SPEEDTEST BY OOKLA' -ForegroundColor Blue }
        else { Write-Host 'STATUS: GOTOWY - OOKLA NIEDOSTEPNA, UZYTE ZOSTANIE CLOUDFARE' -ForegroundColor Yellow }
    }
    Write-Host ''
    Write-Host '[S] START TESTU' -ForegroundColor Blue
    Write-Host '[0] WYJSCIE' -ForegroundColor Red
}

function Invoke-OoklaSpeedTest([string]$Executable) {
    $rawOutput = & $Executable '--accept-license' '--accept-gdpr' '--format=json' 2>&1
    if ($LASTEXITCODE -ne 0) { throw "Speedtest by Ookla zakonczyl sie kodem ${LASTEXITCODE}: $($rawOutput -join ' ')" }
    try { $data = ($rawOutput -join "`n") | ConvertFrom-Json -ErrorAction Stop }
    catch { throw "Nie udalo sie odczytac wyniku Speedtest by Ookla. $($_.Exception.Message)" }
    if (-not $data.download.bandwidth -or -not $data.upload.bandwidth) { throw 'Speedtest by Ookla nie zwrocil pelnych danych.' }
    [pscustomobject]@{
        Engine = 'SPEEDTEST BY OOKLA'; Server = "$($data.server.name) - $($data.server.location)"; Isp = $data.isp
        PingMs = [Math]::Round([double]$data.ping.latency, 1)
        DownloadMbps = [Math]::Round((([double]$data.download.bandwidth * 8) / 1000000), 1)
        UploadMbps = [Math]::Round((([double]$data.upload.bandwidth * 8) / 1000000), 1)
        PacketLoss = if ($null -ne $data.packetLoss) { [Math]::Round([double]$data.packetLoss, 1) } else { $null }
        DownloadedMB = $null; DownloadSeconds = $null; UploadedMB = $null; UploadSeconds = $null; ResultUrl = $data.result.url
    }
}

function Invoke-CloudflareFallbackTest {
    $pingReplies = @(Test-Connection -ComputerName '1.1.1.1' -Count 3 -ErrorAction Stop)
    $pingMs = [Math]::Round((($pingReplies | ForEach-Object ResponseTime | Measure-Object -Average).Average), 1)
    $downloadBytesPerStream = 90000000; $uploadBytesPerStream = 20000000; $streamCount = 4; $downloadRounds = 5; $uploadRounds = 4
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    [Net.ServicePointManager]::DefaultConnectionLimit = 16
    $downloadedBytes = [long]0; $downloadTimer = [Diagnostics.Stopwatch]::StartNew()
    1..$downloadRounds | ForEach-Object {
        $clients = @(); $tasks = @()
        try {
            1..$streamCount | ForEach-Object {
                $client = New-Object Net.WebClient; $clients += $client
                $url = "https://speed.cloudflare.com/__down?bytes=$downloadBytesPerStream&nocache=$([Guid]::NewGuid())"
                $tasks += $client.DownloadDataTaskAsync($url)
            }
            [Threading.Tasks.Task]::WaitAll([Threading.Tasks.Task[]]$tasks)
            $downloadedBytes += [long](($tasks | ForEach-Object { $_.Result.Length } | Measure-Object -Sum).Sum)
        } finally { $clients | ForEach-Object Dispose }
    }
    $downloadTimer.Stop()
    $payload = New-Object byte[] $uploadBytesPerStream; (New-Object Random).NextBytes($payload)
    $uploadedBytes = [long]0; $uploadTimer = [Diagnostics.Stopwatch]::StartNew()
    1..$uploadRounds | ForEach-Object {
        $clients = @(); $tasks = @()
        try {
            1..$streamCount | ForEach-Object {
                $client = New-Object Net.WebClient; $clients += $client
                $tasks += $client.UploadDataTaskAsync('https://speed.cloudflare.com/__up', 'POST', $payload)
            }
            [Threading.Tasks.Task]::WaitAll([Threading.Tasks.Task[]]$tasks)
            $uploadedBytes += [long]$uploadBytesPerStream * $streamCount
        } finally { $clients | ForEach-Object Dispose }
    }
    $uploadTimer.Stop(); $downloadSeconds = [Math]::Max(0.01, $downloadTimer.Elapsed.TotalSeconds); $uploadSeconds = [Math]::Max(0.01, $uploadTimer.Elapsed.TotalSeconds)
    [pscustomobject]@{
        Engine = 'CLOUDFLARE (ZAPASOWY)'; Server = 'Cloudflare'; Isp = $null; PingMs = $pingMs
        DownloadedMB = [Math]::Round($downloadedBytes / 1MB, 1); DownloadSeconds = [Math]::Round($downloadSeconds, 2); DownloadMbps = [Math]::Round((($downloadedBytes * 8) / 1MB) / $downloadSeconds, 1)
        UploadedMB = [Math]::Round($uploadedBytes / 1MB, 1); UploadSeconds = [Math]::Round($uploadSeconds, 2); UploadMbps = [Math]::Round((($uploadedBytes * 8) / 1MB) / $uploadSeconds, 1)
        PacketLoss = $null; ResultUrl = $null
    }
}

function Invoke-SpeedTest {
    $ookla = Find-OoklaSpeedtest
    if ($ookla) { return Invoke-OoklaSpeedTest $ookla }
    Invoke-CloudflareFallbackTest
}

$result = $null
while ($true) {
    Show-SpeedScreen $result
    $key = [Console]::ReadKey($true).Key.ToString()
    if (($key -eq 'D0') -or ($key -eq 'NumPad0')) { return }
    if ($key -eq 'S') {
        Clear-Host; Write-Host 'TEST PREDKOSCI W TOKU...' -ForegroundColor Blue
        try { $result = Invoke-SpeedTest }
        catch { Write-Host "Blad testu: $($_.Exception.Message)" -ForegroundColor Red; Start-Sleep -Seconds 4 }
    }
}
