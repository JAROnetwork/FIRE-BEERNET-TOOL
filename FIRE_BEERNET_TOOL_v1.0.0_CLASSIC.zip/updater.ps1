param(
    [Parameter(Mandatory = $true)]
    [string]$CurrentVersion
)

$ErrorActionPreference = 'Stop'
$ManifestUrl = 'https://jaronetwork.github.io/FIRE-BEERNET-TOOL/latest.json'
$DownloadPage = 'https://jaronetwork.github.io/FIRE-BEERNET-TOOL/'

function Write-UpdateLine {
    param([string]$Text, [string]$Color = 'White')
    Write-Host $Text -ForegroundColor $Color
}

Clear-Host
if (Get-Command Write-Banner -ErrorAction SilentlyContinue) {
    Write-Banner
}

Write-UpdateLine 'AKTUALIZACJA' 'Green'
Write-UpdateLine ''
Write-UpdateLine "Zainstalowana wersja: v$CurrentVersion" 'White'
Write-UpdateLine 'Sprawdzanie informacji na oficjalnej stronie...' 'Cyan'

try {
    $release = Invoke-RestMethod -Uri $ManifestUrl -TimeoutSec 12 -ErrorAction Stop
    if ([string]::IsNullOrWhiteSpace($release.version)) { throw 'Brak numeru wersji w informacji o wydaniu.' }

    $onlineVersion = [version]$release.version
    $localVersion = [version]$CurrentVersion

    Write-UpdateLine "Wersja na stronie: v$onlineVersion" 'White'
    if ($onlineVersion -gt $localVersion) {
        Write-UpdateLine ''
        Write-UpdateLine 'DOSTEPNA JEST NOWA WERSJA.' 'Yellow'
        if ($release.releaseNotes) { Write-UpdateLine $release.releaseNotes 'Cyan' }
        Write-UpdateLine ''
        Write-UpdateLine '[S] OTWORZ STRONE POBIERANIA' 'Green'
        Write-UpdateLine '[0] POWROT DO MENU' 'Red'
        do { $key = [Console]::ReadKey($true).Key } while ($key -ne [ConsoleKey]::S -and $key -ne [ConsoleKey]::D0 -and $key -ne [ConsoleKey]::NumPad0)
        if ($key -eq [ConsoleKey]::S) { Start-Process $DownloadPage }
    }
    else {
        Write-UpdateLine ''
        Write-UpdateLine 'MASZ NAJNOWSZA WERSJE.' 'Green'
        Write-UpdateLine ''
        Write-UpdateLine '[0] POWROT DO MENU' 'Red'
        do { $key = [Console]::ReadKey($true).Key } while ($key -ne [ConsoleKey]::D0 -and $key -ne [ConsoleKey]::NumPad0)
    }
}
catch {
    Write-UpdateLine ''
    Write-UpdateLine "Nie udalo sie sprawdzic aktualizacji: $($_.Exception.Message)" 'Red'
    Write-UpdateLine 'Program niczego nie pobral ani nie uruchomil.' 'White'
    Write-UpdateLine ''
    Write-UpdateLine '[0] POWROT DO MENU' 'Red'
    do { $key = [Console]::ReadKey($true).Key } while ($key -ne [ConsoleKey]::D0 -and $key -ne [ConsoleKey]::NumPad0)
}
