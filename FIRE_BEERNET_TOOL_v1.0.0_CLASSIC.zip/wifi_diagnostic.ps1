# Local Wi-Fi signal helper. It reads Windows' current Wi-Fi signal only;
# it never changes router settings.
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false)

function Get-WifiReading {
    $raw = (& netsh wlan show interfaces 2>&1 | Out-String)
    $percentMatch = [regex]::Match($raw, '(?m):\s*(\d{1,3})%\s*$')
    $ssidMatch = [regex]::Match($raw, '(?im)^\s*SSID\s*:\s*(.+)$')
    if (-not $percentMatch.Success) { return $null }
    $signal = [int]$percentMatch.Groups[1].Value
    # Approximate conversion; the percentage remains the primary reading.
    $rssi = [int][Math]::Round(($signal / 2.0) - 100)
    [pscustomobject]@{ Signal = $signal; Rssi = $rssi; Ssid = if ($ssidMatch.Success) { $ssidMatch.Groups[1].Value.Trim() } else { 'nieznana' } }
}

$best = $null
$worst = $null
$latest = $null
$sampleCount = 0
$measuring = $true

function Write-PanelLine([string]$Text, [string]$Color = 'White') {
    # Erase only this line before overwriting it, without redrawing the header.
    $width = [Math]::Max(1, [Console]::WindowWidth - 1)
    [Console]::Write((' ' * $width))
    [Console]::SetCursorPosition(0, [Console]::CursorTop)
    Write-Host $Text -ForegroundColor $Color
}

Clear-Host
if (Get-Command Write-Banner -ErrorAction SilentlyContinue) {
    Write-Banner -WifiOnly
} else {
    Write-Host 'WiFi NARZEDZIE DIAGNOSTYCZNE' -ForegroundColor Cyan
}
Write-Host ''
Write-Host 'Ciagly pomiar sygnalu pomocny przy recznym ustawianiu anten.' -ForegroundColor White
Write-Host 'Nie zmienia ustawien routera ani nie laczy sie z jego panelem.' -ForegroundColor White
Write-Host ''
$panelTop = [Console]::CursorTop

while ($true) {
    if ($measuring) {
        $latest = Get-WifiReading
        $sampleCount++
        if ($latest -and (($null -eq $best) -or ($latest.Rssi -gt $best.Rssi))) { $best = $latest }
        if ($latest -and (($null -eq $worst) -or ($latest.Rssi -lt $worst.Rssi))) { $worst = $latest }
    }

    [Console]::SetCursorPosition(0, $panelTop)
    if ($measuring) {
        Write-PanelLine 'STATUS: POMIAR W TOKU' Yellow
    } else {
        Write-PanelLine 'STATUS: POMIAR ZATRZYMANY' Yellow
    }
    Write-PanelLine "Probki w tej sesji: $sampleCount" Yellow
    Write-PanelLine ''
    if ($latest) {
        Write-PanelLine "SSID: $($latest.Ssid)" White
        Write-PanelLine "Aktualny sygnal: $($latest.Signal)% | Szacowane RSSI: $($latest.Rssi) dBm" Yellow
    } elseif ($measuring) {
        Write-PanelLine 'Nie wykryto aktywnego polaczenia Wi-Fi.' Yellow
        Write-PanelLine ''
    } else {
        Write-PanelLine ''
        Write-PanelLine ''
    }
    if ($best) { Write-PanelLine "Najlepszy wynik: $($best.Signal)% | ok. $($best.Rssi) dBm | SSID: $($best.Ssid)" Green } else { Write-PanelLine '' }
    if ($worst) { Write-PanelLine "Najgorszy wynik: $($worst.Signal)% | ok. $($worst.Rssi) dBm | SSID: $($worst.Ssid)" Red } else { Write-PanelLine '' }
    Write-PanelLine ''
    Write-PanelLine '[0] WYJSCIE' Red

    # Refresh once per second while still responding quickly to S or Q.
    $until = (Get-Date).AddSeconds(1)
    while ((Get-Date) -lt $until) {
        if ([Console]::KeyAvailable) {
            $key = [Console]::ReadKey($true).Key.ToString()
            if (($key -eq 'Q') -or ($key -eq 'D0') -or ($key -eq 'NumPad0')) { return }
            if ($key -eq 'S') { $measuring = $false; break }
        }
        Start-Sleep -Milliseconds 80
    }
    # Redraw immediately to show the stopped state after pressing S.
    if (-not $measuring) { continue }
}
